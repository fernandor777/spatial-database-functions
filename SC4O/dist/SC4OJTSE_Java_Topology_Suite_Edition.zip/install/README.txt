When you have extracted the SC4O.zip file:

1. Change to the install directory.
2. Execute:
   rename install_sh    install.sh
   rename install_cmd   install.cmd
   rename load_jar_cmd  load_jar.cmd
   rename drop_jar_cmd  drop_jar.cmd
   rename run_ncomp_cmd run_ncomp.cmd
3. Execute install.cmd or install.sh
   Do NOT execute the other three cmd files independently of install.cmd

NOTE 1: I do not have any Linux/UNIX virtual machines running Oracle. 
        As such I have not ever tested the sample install.sh script. 
        The install.sh script may be out of date so please be careful when 
        using it. If it is out of date, fix it and send it back to me as 
        your contribution to the free software you are using.

NOTE 2: The source code is available by contacting the author.

NOTE 3: If you find bugs or extend it by exposing other JTS
        etc functionality, please provide me with a version as part of your 
        contribution to this free software project.

Simon Greener
Allens Rivulet, Tasmania, Australia
simon@spdba.com.au
