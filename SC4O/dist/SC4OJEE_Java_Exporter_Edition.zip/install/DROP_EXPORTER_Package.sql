define defaultSchema='&1'

SET VERIFY OFF;

drop package body SC4O;
drop package      SC4O;
drop package body Exporter;
drop package      EXPORTER;

Exit;

