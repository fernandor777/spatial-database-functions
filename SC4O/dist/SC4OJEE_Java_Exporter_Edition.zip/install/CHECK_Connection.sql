Prompt Connection successful
quit;
